import pandas as pd

# CSV
pokemon_df = pd.read_csv('pokemon_data.csv', dtype={"Name": str, "Type 1": str, "Speed": int,"Generation": str,})

#EXCEL
#pokemon_df_excel = pd.read_excel('pokemon_data.xlsx')

#TXT con tabulación
#pokemon_df_txt = pd.read_csv('pokemon_data.txt', delimiter='\t')

'''
IMPRIMIR VALORES
'''
#print(pokemon_df)



'''
IMPRIMIR LOS PRIMEROS 5 POKEMONS 
'''
#print(pokemon_df.head(5))

'''
IMPRIMIR LOS ÚLTIMOS 5 POKEMONS
'''
#print(pokemon_df.tail(5))

'''
NOMBRES DE LAS COLUMNAS 
'''
#print(pokemon_df.columns)

'''
TODOS LOS VALORES DE LA COLUMNA Name
'''
#nombres = pokemon_df["Name"]
#print(nombres)

'''
OBTENER TODOS LOS NOMBRES Y VELOCIDADES EN UNA SOLA VARIABLE 
'''
#nombres_velocidades = pokemon_df[['Name', 'Speed']] #Hay dos corchetes porque es coger algo [ de la lista x ]
#print(nombres_velocidades)

'''
LOS PRIMEROS 5 NOMBRES
'''
#primeros_5 = pokemon_df['Name'][0:5]
#print(primeros_5)

'''
OBTENER FILAS 
'''
#print('FILA 1:')
#print(pokemon_df.iloc[0])

'''
OBTENER VARIAS FILAS
'''
#print('FILA 0 HASTA 3:')
#print(pokemon_df.iloc[0:3])

'''
OBTENER EL NOMBRE DE LA FILA 1
'''
#print(pokemon_df.iloc[0][1]) #Fila 0 columna 1

'''
ITERAR PARA TODOS Y MOSTRAR EL ÍNDICE Y NOMBRE DE CADA POKEMON
'''
#for i, pokemon in pokemon_df.iterrows(): #nos devuelve el iterador de filas 
#  print(i, pokemon['Name'])

'''
NOMBRES POKEMON TIPO 1 (AGUA)
'''
#print(pokemon_df.loc[pokemon_df['Type 1'] == 'Water'])

'''
ESTADÍSTICAS
'''
#print(pokemon_df.describe())

'''
ORDENACIÓN
'''
#print(pokemon_df.sort_values('Name', ascending=True))

'''
ORDENACIÓN MÁS COMPLEJA
'''
#print(pokemon_df.sort_values(['Type 1', 'HP'], ascending=[True, False])[['Name', 'Type 1', 'HP']])

'''
CREAR UNA COLUMNA EXTRA CALCULADA
'''
#pokemon_df['Total'] = pokemon_df['HP'] + pokemon_df['Attack'] +pokemon_df['Defense'] +pokemon_df['Speed']

#print(pokemon_df['Total'])

'''
MOSTRAR LOS 5 MEJORES
'''
print(pokemon_df.sort_values('Total', ascending=False).Head(3)[['Name', 'Total']])

'''
ELIMINAR LA COLUMNA TOTAL
'''
pokemon_df = pokemon_df.drop(columns=['Total'])