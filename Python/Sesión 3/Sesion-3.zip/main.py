	
from math import sqrt as raiz, sin as seno, cos #Alias para coseno si no seria cos as coseno 
 
numero: int = 16
  
print(f'La raíz cuadrada de {numero} es {raiz(numero)}') #imprime 4.0
print(f'El Seno de {numero} es {seno(numero)}') #imprime -0.287...
print(f'El Coseno de {numero} es {cos(numero)}') #imprime -0.957...

# Para que se ejecute el archivo cordilidad.py hay que importarlo ( llamarlo a ejecutarejecutarlo) en main.py 

from cordialidad import saludar

saludar('Jose')

# Paquetes .py

#Archivo main.py
from utilidades.interacciones.cordialidad import saludar
from utilidades.kpis import puntuacion
 
puntos = puntuacion(0)
 
print(f'{saludar("Pedro")} tu puntuación es de {puntos}')

# Chiste chuck Norris 

#Archivo main.py
from HTTP_Requests.chuck_norris_dice import obtenerChiste
 
#Lo ejecutamos
obtenerChiste()

#Parámetros del coche 

from models.Coche import Coche

miCoche: Coche = Coche('Fiat', 'Punto', 'Negro', '6451FMB', '123', 'Martín')
  
miCoche.acelerar(presion=3)


#Parametros Persona

from models.Persona import Persona 

miPersona:Persona = Persona("Jose", "Rodríguez","23")
miPersona.saludar("Jose","Rodríguez","23")


