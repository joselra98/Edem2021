	
#Archivo utilidades/interacciones/cordialidad.py
 
def saludar(nombre:str):
  return (f'Hola {nombre}')