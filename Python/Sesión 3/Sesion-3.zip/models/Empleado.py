from Persona import Persona

class Empleado (Persona): #persona pasa todos los datos de persona a la clase empleado
  puesto:str
  pHoras:float
  hTrabajadas: int = 0
  cobro: float = 0.0


def __init__(self,Nombre, Apellidos, Edad, puesto, pHora):
  #Llamamos al contructor del padre (persona)
  super(Empleado, self).__init__(Nombre, Apellidos, Edad) #super hace referencia a persona, init es el constructor de empleado
  #Inicializar los atributos propios del empleado
  self.puesto = puesto
  self.pHora = pHora

def trabajar(self, horas:int): #self hace referencia a la variable en este caso persona
  self.hTrabajadas += horas
  print(f'(self.Nombre) ha trabajado (horas). En toal lleva trabajadas: (self.hTrabajadas) horas')

def cobrar(self):
  self.cobro = self.pHora*self.hTrabajadas
  print(f'(self.Nombre) cobra: (self.cobro)€')

# en python siempre hay que poner self antes del módulo si vamos a usarlo dentro 