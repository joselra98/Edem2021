
class Persona():
    Nombre:str
    Apellido:str
    Edad:str
   
    
    # parámetros de la clase coche 
    def __init__(self, Nombre, Apellido, Edad):  
      self.Nombre = Nombre
      self.Apellido = Apellido
      self.Edad = Edad
    
    def saludar(self,Nombre,Apellido,Edad):
      print('Hola, me llamo ' + Nombre+" " + Apellido + " tengo " + Edad + ' Años ')