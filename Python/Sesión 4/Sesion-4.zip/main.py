from models.Animal import Animal
from models.Carnivoro import Carnivoro
from models.Hervivoros import Hervivoro
from models.omnivoros import omnivoro 

Perro:Animal = Animal('7', '4', 'Guau Guau', 'Pluto')
Perro.hacerRuido()
Perro.comer (2)

Gato:Animal = Animal ('5', '4', 'Miau Miau', 'Bola de Nieve')
Gato.hacerRuido()
Gato.comer(1)

Leon:Carnivoro = Carnivoro ('5', '4', 'aarrrrr', 'Simba')
Leon.hacerRuido()
Leon.comer(15)

Vaca:Hervivoro = Hervivoro ('12', '4', 'muuuuuu', 'Paquita')
Vaca.hacerRuido()
Vaca.comer(20)

Humano:omnivoro = omnivoro ('40', '2', 'Hola', 'Carlos')
Humano.hacerRuido()
Humano.comer(1)