from models.Animal import Animal

class Hervivoro(Animal):
  tipo: str = 'Hierva'

  def __init__(self, edad, nPatas, ruido, nombre):
    super(Hervivoro, self).__init__(edad, nPatas, ruido, nombre)

  def comer(self, kilos:int): 
        self.kComida += kilos
        print(f'{self.nombre} ha comido {kilos} Kilos. En total ha comido {self.kComida} Kilos de {self.tipo}')