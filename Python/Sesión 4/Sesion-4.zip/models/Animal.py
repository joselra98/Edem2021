class Animal():
    edad:str
    nPatas:str
    ruido:str
    nombre:str
    kComida: int = 0
   
    # parámetros de la clase animal 
    def __init__(self, edad, nPatas, ruido, nombre):  
      self.edad = edad
      self.nPatas = nPatas
      self.ruido = ruido
      self.nombre = nombre
    
    def hacerRuido (self):
      print(f'{self.nombre} hace el ruido de {self.ruido}')

    def comer(self, kilos:int): 
        self.kComida += kilos
        print(f'{self.nombre} ha comido {kilos} Kilos. En total ha comido {self.kComida} Kilos')
