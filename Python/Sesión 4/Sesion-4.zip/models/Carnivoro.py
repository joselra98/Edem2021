from models.Animal import Animal

class Carnivoro(Animal):
  tipo: str = 'carne'

  def __init__(self, edad, nPatas, ruido, nombre):
    super(Carnivoro, self).__init__(edad, nPatas, ruido, nombre)

  def comer(self, kilos:int): 
        self.kComida += kilos
        print(f'{self.nombre} ha comido {kilos} Kilos. En total ha comido {self.kComida} Kilos de {self.tipo}')

  





