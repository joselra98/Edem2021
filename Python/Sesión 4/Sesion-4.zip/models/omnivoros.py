from models.Animal import Animal 
from models.Carnivoro import Carnivoro
from models.Hervivoros import Hervivoro 

class omnivoro(Animal):
  tipo:str = 'comida'

  def __init__(self, edad, nPatas, ruido, nombre):
    super(omnivoro, self).__init__(edad, nPatas, ruido, nombre)

  def comer(self, kilos:int): 
    self.kComida += kilos
    print(f'{self.nombre} ha comido {kilos} Kilos. En total ha comido {self.kComida} Kilos de {self.tipo}')


  