'''En Python, la estructura es con "elif" y no con "else if"'''
miEdad: int = 31
if (miEdad >= 60):    
   print('Apuntarse al gym')
elif (miEdad < 60 and miEdad > 30): #Una vez entre por la segunda ya no comprueba el resto 
  print ('Adulto maduro')
elif (miEdad == 31):    
  print ('Adulto en su sweet moment')
elif (miEdad < 30 and miEdad >= 18):    
    print ('Adulto joven, todo en orden')
else:    
  print ('¡A clase!')

#Bucles 
#Números del 1 al 100

for i in range(101):
  print(i)

	
lista = [1,2,3,4,5,6,7,8]
 
for elemento in lista:
    if(elemento % 2 == 0):
        print(f'{elemento} es par')
    else:
        print(f'{elemento} es impar')

print(elemento)

#Condición que se acabe la lista 

for elemento in lista:
    if(elemento % 2 == 0):
        print(f'{elemento} es par')
        continue
    else:
        print(f'{elemento} es impar')
        break #al encontrar un break pararía la lista 

for elemento in lista:
    if(elemento % 2 == 0):
        print(f'{elemento} es par')
        break #pararía el econtrar un par 
    else:
        print(f'{elemento} es impar')
        continue

for elemento in lista:
    if(elemento % 2 == 0):
      pass #entra por aqui pero no hace nada en esas condiciones, solo ejecuta los impares
      print(f'{elemento} es par')    
    else:
        print(f'{elemento} es impar')
        continue


#while marca el número de iteraciones que vamos a realizar, ejecuta esto mientras se cumpla esta condición

	
lista = [1,2,3,4,5,6,7,8]
 
# Bucle WHILE para encontrar eliminar elementos hasta que la longitud sea 3
while (len(lista) > 3): #len para sacar la longitud de una lista o un elemento el número de caracteres que tienes 
    lista.pop() #eliminar el elemento, se va imprimiendo la lista y elimando elementos de la lista. Si a pop no le pasamos nada se va al último elemento de la lista 
    print(lista)

	
lista = [1,2,3,4,5,6,7,8]
 
# Bucle WHILE para encontrar eliminar elementos hasta que la longitud sea 3
while (len(lista) > 3):
    lista.pop(2) #si le pones un 2 borraria la posición 2 de la lita o elemento 
    print(lista)

	
# ¡Bucle INFINITO! Mucho cuidado
suma: int = 0
while True:
    suma+=1
    print(suma)
    break # si no pones break se hace infinito 

#DoWhile al menos se ejecuta una vez, mientras que el While puede no ejecutarse nunca 

	
# Python NO CUENTA con bucles DO - WHILE, pero se pueden simular:
i = 1  
 
while True:  
    print(i)  
    i = i + 1  
    if(i > 5):  
        break

#función algo que se puede reutilizar, me va devolver algo
#Procedimiento es una función, pero es como un print
#método funciones privadas o públicas de las compile. un  .pop es un método de la clase lusta 

#robert c martin 

#def para definir funciones 
'''	
def nombreFunción (parámetros) -> tipo_retorno: si pogo el tipo de retorno hay que poner return 
	# declaración de variables
	# y ejecución de código 

'''

	
# Función Básica
def miFuncion():
  print(f"Esto es una función básica")
 
# Llamamdo y ejecutando la función no puede haber dos funciones con el mismo nombre 
miFuncion()   

	
# Función con Parámetros No Tipados
def miFuncionConParametros(a,b):
    print(f"¡{a}, {b}!")  #Hola seria a y b sería mundo 
 
 
# llamando la función y pasándole algunos parámetros
miFuncionConParametros('Hola', 'Mundo')
miFuncionConParametros('Adios', 'Mundo')

# Función con Parámetros No Tipados
def miFuncionConParametros(a,b):
    print(f"¡{a} + {b}!")  #Hola seria a y b sería mundo 
 
 
# llamando la función y pasándole algunos parámetros
miFuncionConParametros('Hola', 'Mundo')
miFuncionConParametros('1', '2')

# Función con Parámetros Tipados
def miFuncionConParametrosTipados(a: str, b: str) :
    print(f"¡{a}, {b}!")
 
 
# llamando la función y pasándole algunos
# parámetros tipados
miFuncionConParametrosTipados('Hola', 'Mundo')
miFuncionConParametrosTipados('1', '2')


# Función con parámetros por defecto
# Si un valor no viene, se pone por defecto
def miFuncionConParametrosPorDefecto(a, b = 1) :
    print(f"La división es {a/b}")
 
 
# llamando la función y pasándole los dos parámetros
miFuncionConParametrosPorDefecto(3, 4)
# llamando la función y pasándole un único parámetro
miFuncionConParametrosPorDefecto(3)


# Función con muchos parámetros con el * indicamos que los elementos es una lista de elementos pero no sabemos los parámetros
def miFuncionConMultiplesParametros(*elementos) :
    for elemento in elementos:
        print(f"Elemento: {elemento}")
 
# llamando la función y pasándole una lista de parámetros
lista: [int] = [1, 2, 3, 4, 5]
miFuncionConMultiplesParametros(*lista, 6,7,8)

# Función con muchos parámetros
def miFuncionConMultiplesParametros(*elementos) :
    for elemento in elementos:
        print(f"Elemento: {elemento}")
 
# llamando la función y pasándole una lista de parámetros
miFuncionConMultiplesParametros(1,2,3,4,5)

# Función con Retorno
def miFuncionConRetorno(): 
    return '¡Hola, Mundo!'
 
# llamando, ejecutando y almacenando el retorno en una variable
# la variable hola_mundo acabará valiendo "¡Hola, Mundo!"
hola_mundo = miFuncionConRetorno() #con esto guardamos el restultado en una variable
print(hola_mundo)


	
# Función con Retorno Tipado
def miFuncionConRetornoTipado(*elementos) -> int :
    # Inicializamos la variable suma a 0 para incrementarla después
    suma: int = 0
 
    # iteramos sobre los elementos y los vamos sumando uno a uno
    # los guardamos en la variable suma que se va incrementando
    for elemento in elementos:
        print(f"Elemento: {elemento}")
        suma += elemento
 
    return suma
 
# llamar, pasarle la lista, ejecutar y almacenar la suma del retorno
# en la variable sumatorio
lista_numeros = [1, 2, 3, 4, 5, 6]
sumatorio = miFuncionConRetornoTipado(*lista_numeros)
print(f"EL sumatorio total es: {sumatorio}")


	
''' PASO POR REFERENCIA
Paso de parámetros por Referencia
 
Los valores simples se pasan, por defecto, por valor
Los valores complejos se pasan, por defecto, por referencia
 
'''
 
# las listas al ser complejos se pasan por referencia
# Esto quiere decir que si la función edita el parámetro,
# éste se edita también en origen
 
def doblar_valores(numeros):
    for i,n in enumerate(numeros): #la i es la posición y la n es el valor 
        numeros[i] *= 2

# definiendo una variable que se va a pasar por referencia
ns = [10,50,100]
doblar_valores(ns)
print(f"Lista Original Modificada: {ns}") #[20, 100, 200]





	
# SI NO QUEREMOS PASAR UNA LISTA COMO REFERENCIA, DEBEMOS REALIZAR UNA COPIA "AL VUELO"
# Ahora esta no se pasará por referencia, ya que haremos una copia del valor
ns = [10,50,100]
doblar_valores(ns[:])  # con [:] trae todos los valoes de la lista Una copia al vuelo de una lista se realiza con [:]
# Esto hace que la lista original no se vea modificada
print(f"Lista Original No Modificada: {ns}") #[10, 50, 100]

	
# Para aquellos tipos de datos simples, si queremos el mismo comportamiento
# de paso por referencia podemos:
 
# SOBRESCRIBIR EL VALOR ORIGINAL CON EL VALOR DE RETURN DE LA FUNCIÓN al ser un tipo promitivo se pasa por valor y no por referencia por lo que al indicar el valor de n lo cambia y si no lo cambiaria 
def doblar_valor(numero):
    return numero * 2
 
n = 10
n = doblar_valor(n)
print(f"Valor original Modificado: {n}")


''' FUNCIONES LAMBDA:
 
Las funciones Lambda de Python son bastante habituales.
 
'''
 
al_cuadrado = lambda a: a**2
 
# llamando a la función lambda
print(al_cuadrado(2)) # imprimirá un 4



'''
FECHAS
'''
#import para traer liberias
#import locale nos permite esocoger el idioma
#timeStamp para decir como queremos la hora 

import datetime
import time
import calendar 
import locale 

# locale.setlocale(locale.LC_ALL,'es_ES')

print('Fecha y Hora Actual', datetime.datetime.now())
print('Fecha Actual', datetime.date.today())
print('Año Actual', datetime.date.today().strftime("%Y"))
print('Mes Actual Número', datetime.date.today().strftime("%m"))
print('Mes Actual', datetime.date.today().strftime("%B"))
print('Número de la Semana', datetime.date.today().strftime("%W"))
print('Día del año', datetime.date.today().strftime("%j"))
print('Día del Mes ', datetime.date.today().strftime("%d"))
print('Día de la Semana', datetime.date.today().strftime("%A"))


print('Mes', calendar.month_name[10])
print('2020 es Bisiesto?:', calendar.isleap(2020))

ahora = datetime.datetime.now()
timeStamp = time.mktime(ahora.timetuple())

print('TimeStamp', timeStamp)

print('Fecha Legible:',datetime.datetime.fromtimestamp(timeStamp).strftime('%Y-%m-%d %H:%M:%S'))


miFecha = '02/10/2021'

nuevoTimeStamp = time.mktime(datetime.datetime.strptime(miFecha,'%d/%m/%Y').timetuple())

print('Nuevo TimeStamp', nuevoTimeStamp)

print('Fecha Legible:',datetime.datetime.fromtimestamp(nuevoTimeStamp).strftime('%Y-%m-%d'))

lista= set([1,2,3,4,5,6])

def ausentes(lista):
  listaPerfecta = set([0,1,2,3,4,6,7,8,9])
  return listaPerfecta.symmetric_difference(lista)

print(str(ausentes(lista)))

#sorted para ordenador de mayor a menor 
#para cada x posición 1 

precios = [('Producto A', '12.20'), ('Producto B', '15.10'), ('Producto C', '24.50')]

print( sorted(precios, key=lambda x: float(x[1]), reverse=True))
print( sorted(precios, key=lambda x: float(x[1]), reverse=False))
