'''¡Palabras clave en Python!
Estas palabras no se deben usar si no es para el uso que tiene el lenguaje establecido

- and
- as
- assert
- break
- class
- continue
- def
- del
- elif
- else
- except
- exec
- finally
- for
- from
- global
- if
- import
- in
- is
- lambda
- nonlocal
- not
- or
- pass
- raise
- return
- try
- while
- with
- yield
- True
- False
- None
DEFINIDO EN EL APARTADO 1
'''
#Para saber si es par %2 == 0
#https://www.wolframalpha.com/

operacion_compleja = 33 * 10 + 2 / 5 ** 2
print(f"> Operación 33*10+2/5**2 = {operacion_compleja}")

operacion_compleja_2 = (33 * 10) + (2 / (5 ** 2))
print(f"> Operación (33*10)+(2/(5**2)) = {operacion_compleja_2}")

nombre: str = "Martín"
apellidos: str = "San José de Vicente" 

 # Concatenación
nombre_completo: str = nombre + " " + apellidos
print(f"> Nombre completo: {nombre_completo}") 

 # Repetición
nombre_x5: str = nombre*5
print(f"> Nombre 5 veces: {nombre_x5}")

'''
EDEM - Data Anaylitcs

Operadores de Comparación en Python

Los operadores de comparación en Python serían:

> Igualdad: == y también is (operador de identidad positivo)

> Distinción: != y también is not (operador de identidad negativo)

> Mayor qué: >

> Mayor o igual: >=

> Menor qué: <

> Menor o igual: <=

'''
c: int = 3
d: int = 3
e: int = 4

# Igualdad - Nos devolverá True o False
print(f"> ¿3 y 3 son iguales? {c is d}") # Operador Identidad
print(f"> ¿3 y 3 son iguales? {c == d}")
print(f"> ¿3 y 4 son iguales? {c is e}") # Operador Identidad

# Desigualdad - Nos devolverá True o False
print(f"> ¿3 y 3 no son iguales? {c is not d}") # Operador Identidad
print(f"> ¿3 y 4 no son iguales? {c is not e}") # Operador Identidad
print(f"> ¿3 y 3 no son iguales? {c != d}")

# Mayor Qué / Mayor o Igual qué
print(f"¿3 mayor que 2? {3 > 2}")
print(f"¿2 mayor que 3? {2 > 3}")
print(f"¿3 mayor o igual que 3? {3 >= 3}")


# And (y) se tienen que cumplir todas
print(f"> Verdadero y Verdadero = {True and True}")
print(f"> Verdadero y Falso = {True and False}")
print(f"> Verdadero y 1 = {True and 1}") # 1 si comparas true con un valor te edvolverá ese valor 1=true 
print(f"> Falso y Falso = {False and False}") #
print(f"> Falso y 0 = {False and 0}") # 0= false
print(f"> Falso y None = {False and None}") # none=false

# Or (ó) se cumpla una u otra 
print(f"> Verdadero o Verdadero = {True or True}")
print(f"> Verdadero o Falso = {True or False}")
print(f"> Falso o False = {False or False}") # no ha entrado ni por una ni por otra, no se cumple ninguna condición

# Not ( Lo contrario )
print(f"> Not Verdadero = {not True}")
print(f"> Not Falso = {not False}")
print(f"> Not Falso o Verdadero = {not (False or True)}"


'''
	
if (condición):
	# ejecutar una o varias líneas
elif (otra_condición):
	# ejecutar otras sentencias
elif (otra_condición_más):
	# ejecutar otras sentencias
else:
	# ejecutar otras sentencias si no se han 
	# cumplido ningunas de las condiciones anteriores
'''
'''En Python, la estructura es con "elif" y no con "else if"'''

'''En Python, la estructura es con "elif" y no con "else if"'''
miEdad: int = 45
if (miEdad >= 60):    
  print('Apuntarse al gym')
elif (miEdad < 60 and miEdad > 30):    
  print ('Adulto maduro')
elif (miEdad == 30):    
  print ('Adulto en su sweet moment')
elif (miEdad < 30 and miEdad >= 18):    
  print ('Adulto joven, todo en orden')
else:    
  print ('¡A clase!')
